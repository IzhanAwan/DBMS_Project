from django.contrib import admin
from publisher.models import database

# Register your models here.
admin.site.register(database)