from datetime import datetime, timedelta
import pandas as pd
import numpy as np

rates_df = pd.read_excel('C:/Users/PC/FYP/waibeam/publisher/Rates_final.xlsx')

# Load the male ratings data
ratings_male_df = pd.read_excel('C:/Users/PC/FYP/waibeam/publisher/Forecasted_Ratings_Male_2023.xlsx')

# Load the female ratings data
ratings_female_df = pd.read_excel('C:/Users/PC/FYP/waibeam/publisher/Forecasted_Ratings_Female_2023.xlsx')



prime_time_slots = ["19:00 - 20:00", "20:00 - 21:00", "21:00 - 22:00", "22:00 - 23:00"]
non_prime_time_slots = ["08:00 - 09:00", "09:00 - 10:00", "10:00 - 11:00", "11:00 - 12:00",
                            "12:00 - 13:00", "13:00 - 14:00", "14:00 - 15:00", "15:00 - 16:00",
                            "16:00 - 17:00", "17:00 - 18:00", "18:00 - 19:00"]


def allocate_budget(rates_df, top_slots, budget, category):
    """
    Determine which of the top slots can be afforded within the budget.
    Includes detailed information in the output.
    """
    affordable_slots = []
    for _, row in top_slots.iterrows():
        date = row['Date']
        slot = row['Timeband']
        channel = row['Channel']
        rate = rates_df.loc[rates_df['Timeslots'] == slot, channel].iloc[0]  # Get the rate
        if budget >= rate:
            affordable_slots.append((date.strftime("%Y-%m-%d"), channel, slot, category))
            budget -= rate  # Update budget
    return affordable_slots, budget




def select_top_rated_slots(ratings_df, date, time_slots, top_n=3):
    """
    Select the top N rated slots for a given date within the specified time slots.
    Returns a DataFrame including the date for each slot.
    """
    # Filter ratings for the given date and time slots
    daily_slots = ratings_df[(ratings_df['Date'] == date) & (ratings_df['Timeband'].isin(time_slots))]
    # Sort by rating (assuming 'yhat' as rating column)
    top_slots = daily_slots.sort_values('Rating', ascending=False).head(top_n)
    top_slots['Date'] = date  # Add date to the DataFrame
    return top_slots


def plan_ad_slots(start_date, end_date, prime_budget, non_prime_budget, rates_df, ratings_df):
    allocation_plan = []
    current_date = start_date
    while current_date <= end_date:
        for category, time_slots, budget in [('Prime', prime_time_slots, prime_budget),
                                             ('Non-Prime', non_prime_time_slots, non_prime_budget)]:
            top_slots = select_top_rated_slots(ratings_df, current_date, time_slots)
            affordable_slots, new_budget = allocate_budget(rates_df, top_slots, budget, category)
            allocation_plan.extend(affordable_slots)
            # Update the respective budget after allocation
            if category == 'Prime':
                prime_budget = new_budget
            else:
                non_prime_budget = new_budget
        current_date += timedelta(days=1)

    # Calculate the total remaining budget
    remaining_budget = prime_budget + non_prime_budget

    return allocation_plan, remaining_budget


def execute_ad_plan(start_date, end_date, total_budget, prime_time_percentage, category, gender, rates_df):


    # Flip the order when creating the datetime object
    start_date = datetime(start_date[2], start_date[1], start_date[0])
    end_date = datetime(end_date[2], end_date[1], end_date[0])

    # Calculate prime and non-prime budgets
    prime_budget = total_budget * (prime_time_percentage / 100)
    non_prime_budget = total_budget - prime_budget

    # Placeholder for ratings_df based on gender and category
    # Assuming ratings_male_df and ratings_female_df are predefined DataFrames
    if gender.lower() == 'male':
        ratings_df = ratings_male_df  # This should be defined in your context
    elif gender.lower() == 'female':
        ratings_df = ratings_female_df  # This should be defined in your context
    else:
        return "Invalid gender. Please choose 'male' or 'female'."

    # Filter by channel category
    channel_categories = {
        "News": ["GEO NEWS", "ARY NEWS", "SAMAA", "BOL NEWS (URDU)", "EXPRESS NEWS"],
        "Entertainment": ["ARY DIGITAL", "GEO ENTERTAINMENT", "HUM TV", "URDU 1", "A PLUS"]
    }
    if category in channel_categories:
        channels_in_category = channel_categories[category]
        ratings_df = ratings_df[ratings_df['Channel'].isin(channels_in_category)]
    else:
        return "Invalid or unspecified category. Please choose 'News' or 'Entertainment'."

    # Function to select top-rated slots (omitted for brevity, use your existing implementation)
    # Function to allocate budget (omitted for brevity, use your existing implementation)

    # Planning and allocating ad slots (simplified, please integrate with your existing logic)
    allocation_plan, remaining_budget = plan_ad_slots(start_date, end_date, prime_budget, non_prime_budget, rates_df, ratings_df)

    # Convert allocation_plan to DataFrame for display
    allocation_df = pd.DataFrame(allocation_plan, columns=['Date', 'Channel', 'Timeband', 'Category'])
    return allocation_df, remaining_budget

## START ##

# -*- coding: utf-8 -*-
"""FYP_ff.ipynb

Automatically generated by Colaboratory.

Original file is located at
    https://colab.research.google.com/drive/1zmq5d07Ythy8BPqJANoGPwaUyKV-qTGi
"""

# import pandas as pd
# import numpy as np

# # Load the rates data
# rates_df = pd.read_excel('C:/Users/PC/FYP/waibeam/publisher/Rates_final.xlsx')

# # Load the male ratings data
# ratings_male_df = pd.read_excel('C:/Users/PC/FYP/waibeam/publisher/Forecasted_Ratings_Male_2023.xlsx')

# # Load the female ratings data
# ratings_female_df = pd.read_excel('C:/Users/PC/FYP/waibeam/publisher/Forecasted_Ratings_Female_2023.xlsx')

# from datetime import datetime, timedelta
# import pandas as pd

# import pandas as pd
# from datetime import datetime, timedelta

# prime_time_slots = ["19:00 - 20:00", "20:00 - 21:00", "21:00 - 22:00", "22:00 - 23:00"]
# non_prime_time_slots = ["08:00 - 09:00", "09:00 - 10:00", "10:00 - 11:00", "11:00 - 12:00",
#                             "12:00 - 13:00", "13:00 - 14:00", "14:00 - 15:00", "15:00 - 16:00",
#                             "16:00 - 17:00", "17:00 - 18:00", "18:00 - 19:00"]

# # Assuming the data loading remains the same
# def allocate_budget(rates_df, top_slots, budget, category):
#     affordable_slots = []
#     for _, row in top_slots.iterrows():
#         date = row['Date']
#         slot = row['Timeband']
#         channel = row['Channel']
#         rate = rates_df.loc[(rates_df['Timeslots'] == slot) & (rates_df['Channel'] == channel), 'Rate'].iloc[0]
#         if budget >= rate:
#             affordable_slots.append({"Date": date.strftime("%Y-%m-%d"), "Channel": channel, "Slot": slot, "Category": category})
#             budget -= rate
#     return affordable_slots, budget

# def select_top_rated_slots(ratings_df, date, time_slots, top_n=3):
#     daily_slots = ratings_df[(ratings_df['Date'] == date) & (ratings_df['Timeband'].isin(time_slots))]
#     top_slots = daily_slots.sort_values(by='Rating', ascending=False).head(top_n)
#     return top_slots

# def plan_ad_slots(start_date, end_date, prime_budget, non_prime_budget, rates_df, ratings_df):
#     allocation_plan = []
#     current_date = start_date
#     while current_date <= end_date:
#         for category, time_slots, budget in [("Prime", prime_time_slots, prime_budget), ("Non-Prime", non_prime_time_slots, non_prime_budget)]:
#             top_slots = select_top_rated_slots(ratings_df, current_date, time_slots)
#             affordable_slots, budget = allocate_budget(rates_df, top_slots, budget, category)
#             allocation_plan.extend(affordable_slots)
#             if category == "Prime":
#                 prime_budget = budget
#             else:
#                 non_prime_budget = budget
#         current_date += timedelta(days=1)
#     return allocation_plan, prime_budget + non_prime_budget

# def execute_ad_plan(start_date, end_date, total_budget, prime_time_percentage, category, gender, rates_df):
#     print(category)
#     # Date parameters are already datetime objects
#     prime_budget = total_budget * (prime_time_percentage / 100)
#     non_prime_budget = total_budget - prime_budget

#     if gender.lower() == 'male':
#         ratings_df = ratings_male_df
#     elif gender.lower() == 'female':
#         ratings_df = ratings_female_df
#     else:
#         raise ValueError("Invalid gender. Please choose 'male' or 'female'.")

#     channel_categories = {
#         "News": ["GEO NEWS", "ARY NEWS", "SAMAA", "BOL NEWS (URDU)", "EXPRESS NEWS"],
#         "Entertainment": ["ARY DIGITAL", "GEO ENTERTAINMENT", "HUM TV", "URDU 1", "A PLUS"]
#     }
#     if category in channel_categories:
#         channels_in_category = channel_categories[category]
#         ratings_df = ratings_df[ratings_df['Channel'].isin(channels_in_category)]
#     else:
#         raise ValueError("Invalid or unspecified category. Please choose 'News' or 'Entertainment'.")

#     allocation_plan, remaining_budget = plan_ad_slots(start_date, end_date, prime_budget, non_prime_budget, rates_df, ratings_df)
#     allocation_df = pd.DataFrame(allocation_plan)
#     print(allocation_df)
#     print(remaining_budget)
#     return allocation_df, remaining_budget



### endd ####
# Remember to define prime_time_slots and non_prime_time_slots somewhere in your code.
# Also, ensure ratings_male_df and ratings_female_df are loaded and have the expected structure.



# Assuming ratings_male_df and ratings_female_df are loaded similarly as before
# ratings_male_df = ...
# ratings_female_df = ...

# def allocate_budget(rates_df, top_slots, budget, category):
#     affordable_slots = []
#     for _, row in top_slots.iterrows():
#         date = row['Date']
#         slot = row['Timeband']
#         channel = row['Channel']
#         rate = rates_df.loc[rates_df['Timeslots'] == slot, channel].iloc[0]  # Get the rate
#         if budget >= rate:
#             affordable_slots.append((date.strftime("%Y-%m-%d"), channel, slot, category))
#             budget -= rate  # Update budget
#     return affordable_slots, budget

# def select_top_rated_slots(ratings_df, date, time_slots, top_n=3):
#     daily_slots = ratings_df[(ratings_df['ds'] == date) & (ratings_df['Timeband'].isin(time_slots))]
#     top_slots = daily_slots.sort_values(by='yhat', ascending=False).head(top_n)
#     top_slots['Date'] = date  # Add date to the DataFrame
#     return top_slots

# def plan_ad_slots(start_date, end_date, prime_budget, non_prime_budget, rates_df, ratings_df):
#     allocation_plan = []
#     current_date = start_date
#     while current_date <= end_date:
#         for category, time_slots, budget in [('Prime', prime_time_slots, prime_budget),
#                                              ('Non-Prime', non_prime_time_slots, non_prime_budget)]:
#             top_slots = select_top_rated_slots(ratings_df, current_date, time_slots)
#             affordable_slots, new_budget = allocate_budget(rates_df, top_slots, budget, category)
#             allocation_plan.extend(affordable_slots)
#             if category == 'Prime':
#                 prime_budget = new_budget
#             else:
#                 non_prime_budget = new_budget
#         current_date += timedelta(days=1)
#     remaining_budget = prime_budget + non_prime_budget
#     return allocation_plan, remaining_budget

# def execute_ad_plan(start_date_tuple, end_date_tuple, total_budget, prime_time_percentage, category, gender, rates_df):
#     start_date = datetime(start_date_tuple[2], start_date_tuple[1], start_date_tuple[0])
#     end_date = datetime(end_date_tuple[2], end_date_tuple[1], end_date_tuple[0])
#     prime_budget = total_budget * (prime_time_percentage / 100)
#     non_prime_budget = total_budget - prime_budget

#     if gender.lower() == 'male':
#         ratings_df = ratings_male_df
#     elif gender.lower() == 'female':
#         ratings_df = ratings_female_df
#     else:
#         raise ValueError("Invalid gender. Please choose 'male' or 'female'.")

#     channel_categories = {
#         "News": ["GEO NEWS", "ARY NEWS", "SAMAA", "BOL NEWS (URDU)", "EXPRESS NEWS"],
#         "Entertainment": ["ARY DIGITAL", "GEO ENTERTAINMENT", "HUM TV", "URDU 1", "A PLUS"]
#     }
#     if category in channel_categories:
#         channels_in_category = channel_categories[category]
#         ratings_df = ratings_df[ratings_df['Channel'].isin(channels_in_category)]
#     else:
#         raise ValueError("Invalid or unspecified category. Please choose 'News' or 'Entertainment'.")

#     allocation_plan, remaining_budget = plan_ad_slots(start_date, end_date, prime_budget, non_prime_budget, rates_df, ratings_df)
#     allocation_df = pd.DataFrame(allocation_plan, columns=['Date', 'Channel', 'Timeband', 'Category'])
#     return allocation_df, remaining_budget

# Example call to the function:
# allocation_df, remaining_budget = execute_ad_plan(start_date_flip, end_date_flip, total_budget, prime_time_percentage, category, gender, rates_df)

# allocation_records = allocation_df.to_dict('records')
        
# for record in allocation_records:
#     print(record)  # This will print each record in the console

# Print the results
# print(allocation_df)
# print(f"Remaining Budget: {remaining_budget}")

