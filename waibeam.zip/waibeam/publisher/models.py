from django.db import models

# Create your models here.
class database(models.Model):
    budget = models.IntegerField()
    gender = models.CharField(max_length = 8)
    ad = models.IntegerField()
    primetime = models.CharField(max_length = 8)