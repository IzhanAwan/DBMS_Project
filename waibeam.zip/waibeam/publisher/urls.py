from django.contrib import admin
from django.urls import path
from publisher import views

urlpatterns = [
    path("", views.welcome, name = 'welcome'),
    path("advertiser/", views.advertiser1, name = 'advertiser1'),
    path("publisher/", views.publisher, name = 'publisher1'),
    path("advertiser/advertiser2/", views.advertiser2, name = 'advertiser2'),
    path("publisherlogin/", views.publisherlogin, name = 'publisherlogin'),
    path("publisherlogin/publishertable", views.publisherlogin2, name = 'publishertable'),
    path("advertiserform/", views.advertiserform, name = 'advertiserform'),
    path("advertiserform/modelresult/", views.modelresult, name = 'modelresult')
]
