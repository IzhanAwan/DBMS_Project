from django.shortcuts import render, redirect, HttpResponse
from publisher.models import database
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from .fyp_ff import execute_ad_plan
# Create your views here.
def welcome(request):
    return render(request, 'mainpage.html')

def publisherlogin(request):
    return render(request, 'publisherlogin.html')

def publisherlogin2(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            return render(request, "publishertable.html")
        else:
            return render(request,'publisherlogin.html')

    return render(request,'publisherlogin.html')  

def advertiserform(request):
    return render(request, 'advertiserform.html')

def modelresult(request):
    import pandas as pd
    import numpy as np
    from datetime import datetime

    # Initialize context to avoid reference before assignment
    context = {}


    if request.method == 'POST':
        total_budget = int(request.POST.get('budget'))  # Ensure it's an integer
        gender = request.POST.get('gender')
        category = request.POST.get('channeltype')
        prime_time_percentage = float(request.POST.get('primetime'))  # Ensure it's a float
        # Assuming dates are submitted as 'YYYY-MM-DD'
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        print('ghghghg')
        print(prime_time_percentage)

        # Convert string dates to datetime objects
        # start_date = datetime.strptime(start_date, '%Y-%m-%d')
        # end_date = datetime.strptime(end_date, '%Y-%m-%d')
        print(start_date, end_date)
        year, month, day = start_date.split("-")

        start_date_flip = (int(day), int(month), int(year))
        year, month, day = end_date.split("-")
        end_date_flip = (int(day), int(month), int(year))

        # Load the rates data
        rates_df = pd.read_excel('C:/Users/PC/FYP/waibeam/publisher/Rates_final.xlsx')
        print(start_date_flip, end_date_flip, total_budget, prime_time_percentage, category, gender)
        # start_date = (1, 3, 2023)
        # end_date = (14, 3, 2023)
        # total_budget = 2000000  # Example budget
        # prime_time_percentage = 60  # Example prime time percentage
        # category = 'News'  # Example category
        # gender = 'male'  # Example gende
        # Adjust the execute_ad_plan call as necessary
        allocation_df, remaining_budget = execute_ad_plan(start_date_flip, end_date_flip, total_budget, prime_time_percentage, category, gender, rates_df)
        
        # Convert your DataFrame to a format suitable for rendering in the template
        allocation_records = allocation_df.to_dict('records')
        
        
        context = {
            'allocations': allocation_records,
            'remaining_budget': remaining_budget
        }

        print(context)
        for record in allocation_records:
            print(record)  # This will print each record in the console

    return render(request, 'ad_allocation.html', context)



def advertiser1(request):
    return render(request, 'adv1.html')
def advertiser2(request):
    if request.method == 'POST':
        budget = request.POST.get('budget')
        gender = request.POST.get('gender')
        ad = request.POST.get('adDuration')
        primetime = request.POST.get('primetime')
        print(budget, primetime, ad, gender)
        db = database(budget=budget, gender=gender, ad=ad, primetime=primetime)
        db.save()
    return render(request, 'adv2.html')

def publisher(request):
    return render(request, 'pub1.html')